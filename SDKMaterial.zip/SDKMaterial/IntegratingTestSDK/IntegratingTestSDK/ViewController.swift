//
//  ViewController.swift
//  IntegratingTestSDK
//
//  Created by Muhammad Kumail on 01/09/2023.
//

import UIKit
import TestSDK

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

